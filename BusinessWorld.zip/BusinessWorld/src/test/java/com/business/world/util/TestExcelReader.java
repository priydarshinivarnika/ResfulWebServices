package com.business.world.util;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestExcelReader {

	private static final String FILE_PATH = "/Users/vxp142/CUP/BusinessWorld/EmployeeList.xlsx";

	public static void main(String args[]) {

		/*try {
			FileInputStream file = new FileInputStream(new File(FILE_PATH));

			XSSFWorkbook workbook = new XSSFWorkbook(file);
			Sheet sheet = workbook.getSheetAt(0);
			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();

				Iterator<CellType> cellIterator = row.cellIterator();

				while (cellIterator.hasNext()) {
					CellType cell = cellIterator.next();

					switch (cell.getCellType()) {	
						case CellType.STRING:
                        System.out.print(cell.getStringCellValue());
                        break;
						case CellType.BOOLEAN:
                        System.out.print(cell.getBooleanCellValue());
                        break;
                    case CellType.NUMERIC:
                        System.out.print(cell.getNumericCellValue());
                        break;
                }
				}
				System.out.println("\n");
			}
			file.close();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}*/
	}
}
