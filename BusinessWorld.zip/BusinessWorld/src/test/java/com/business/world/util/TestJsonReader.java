package com.business.world.util;

import com.business.world.dto.Address;
import com.business.world.dto.Employee;
import com.business.world.entity.AddressEntity;
import com.business.world.entity.EmployeeEntity;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class TestJsonReader {

    @Test
    public void testJsonToEmployee () {
        List<EmployeeEntity> empList = new ArrayList<>();
        AddressEntity add = new AddressEntity();
        add.setCity("Trivendrum");
        add.setState("Kerala");
        add.setStreetNum("12 Hudson street");
        add.setZip("695583");
        add.setAddressline1("12C");


        EmployeeEntity e = new EmployeeEntity();

        e.setFirstname("varnika");
        e.setLastname("priydarshini");
        e.setSalary(123456);
        e.setAddress(add);
        empList.add(e);

        AddressEntity add2 = new AddressEntity();
        add2.setCity("Ahmedabad");
        add2.setState("Gujrat");
        add2.setStreetNum("12 Jhulelal street");
        add2.setZip("795543");
        add2.setAddressline1("12 Cariappa");


        EmployeeEntity e2 = new EmployeeEntity();

        e2.setFirstname("Vicky");
        e2.setLastname("Malhotra");
        e2.setSalary(34567);
        e2.setAddress(add2);

        empList.add(e2);

        System.out.println(JsonReader.employeeToJson(empList));
        //System.out.println(JsonReader.employeeToJson(e2));
       // System.out.print(str);
    }
}
