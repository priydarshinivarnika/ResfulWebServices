package com.business.world.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

import com.business.world.entity.EmployeeEntity;

public class ExcelToDatabase {

	private SessionFactory sessionFactory;

	@Test
	public void getEmployeeListFormExcel() throws IOException {

		try {
			Configuration config = new Configuration();
			sessionFactory = config.configure("hibernate.cfg.xml").buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}

		Session session = sessionFactory.openSession();

		FileInputStream file = new FileInputStream(new File("exceldatabase.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(0);
		Row row;
		for (int i = 1; i <= sheet.getLastRowNum(); i++) { // points to the starting of excel i.e excel first row
			row = (Row) sheet.getRow(i); // sheet number

			int employeeId=0;
			if (row.getCell(0) == null) {
				employeeId = 0;
			} else
				System.out.println("no primary key");

			String firstName;
			if (row.getCell(1) == null) {
				firstName = "null";
			} // suppose excel cell is empty then its set to 0 the variable
			else
				firstName = row.getCell(1).toString(); // else copies cell data to name variable

			String id;
			if (row.getCell(2) == null) {
				id = "null";
			} else
				id = row.getCell(2).toString();
			String lastName;
			if (row.getCell(2) == null) {
				lastName = "null";
			} else
				lastName = row.getCell(2).toString();
			int salary = 0;
			if (row.getCell(2) == null) {
				salary = 0;
			} else
				System.out.println("no salary");

			session.beginTransaction();
			EmployeeEntity empl = new EmployeeEntity();
			empl.setEmployeeId(employeeId);
			empl.setFirstName(firstName);
			empl.setId(id);
			empl.setLastName(lastName);
			empl.setSalary(salary);
			System.out.println(empl.getEmployeeId() + " - " + empl.getFirstName() + " - " + empl.getId() + " - "
					+ empl.getLastName() + " - " + empl.getSalary());
			session.saveOrUpdate(empl);
			session.getTransaction().commit();
		}
		file.close();
	}

}
