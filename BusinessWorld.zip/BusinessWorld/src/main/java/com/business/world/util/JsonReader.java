package com.business.world.util;

import com.business.world.dto.Employee;
import com.business.world.entity.EmployeeEntity;
import com.google.gson.Gson;

import java.util.List;
import java.util.stream.Collectors;


public class JsonReader {

    static Gson gson = new Gson();
    public static List<String> employeeToJson(List<EmployeeEntity> emp){

        return emp.stream().map(x -> gson.toJson(x)).collect(Collectors.toList());

    }
    public static EmployeeEntity jsonToEmployee(String empJsonList){

        //return gson.fromJson(empJsonList, Employee.class);

       return gson.fromJson(empJsonList, EmployeeEntity.class);

        /* return null; */
    }

}
