package com.business.world.dao;

import java.util.List;

import javax.transaction.SystemException;

import com.business.world.entity.EmployeeEntity;

public interface IDatabaseAccess {

	public Integer createEmployee(EmployeeEntity emp) throws Exception;
	public List<EmployeeEntity> getAllEmployees();
	public List<EmployeeEntity> getEmployeeById(String id);

	public EmployeeEntity updateEmployee(String id, EmployeeEntity emp) throws Exception;

	public void deleteEmployee(String id) throws Exception;
	public List<Integer> createEmployee(List<EmployeeEntity> empList) throws Exception;
	}
