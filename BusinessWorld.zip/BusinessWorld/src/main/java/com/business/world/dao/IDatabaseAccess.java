package com.business.world.dao;

import com.business.world.entity.EmployeeEntity;

import java.util.List;

public interface IDatabaseAccess {

   public void createEmployee(EmployeeEntity emp);

}
