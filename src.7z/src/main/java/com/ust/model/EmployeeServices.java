package com.ust.model;

public interface EmployeeServices {

	/* Method to CREATE an employee in the database */
	Integer addEmployee(String email, String firstName, String lastName, String department);

	/* Method to READ all the employees */
	void listEmployees();

	// Method to READ the employee by id
	void fetchEmployeeById(int id);

	// Method to READ the employee by department
	void fetchEmployeeByDepartment(String department);

	/* Method to UPDATE department for an employee */
	void updateEmployee(int id, String department);

	/* Method to DELETE an employee from the records */
	void deleteEmployee(Integer EmployeeID);
	
	/* Method to print total number of records */
	void countEmployee();

}