package com.ust.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;

import com.ust.utility.HibernateUtil;

@Entity(/* name = "JoinTableEmployeeEntity" */)
@Table(name = "EMPLOYEE", uniqueConstraints = {
		@UniqueConstraint(columnNames = "ID"),
		@UniqueConstraint(columnNames = "EMAIL") })
public class EmployeeEntity implements Serializable, EmployeeServices {

	private static final long serialVersionUID = -1798070786993154676L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private Integer employeeId;

	@Column(name = "EMAIL", unique = true, nullable = false, length = 100)
	private String email;

	@Column(name = "FIRST_NAME", unique = false, nullable = false, length = 100)
	private String firstName;

	@Column(name = "LAST_NAME", unique = false, nullable = false, length = 100)
	private String lastName;

	@Column(name = "Department", unique = false, nullable = false, length = 100)
	private String department;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "EMPLOYEE_SKILL", joinColumns = { @JoinColumn(name = "EMPLOYEE_ID", referencedColumnName = "ID") }, 
	inverseJoinColumns = { @JoinColumn(name = "SKILL_ID", referencedColumnName = "ID") })
	private Set<SkillEntity> skills = new HashSet<SkillEntity>();

	public EmployeeEntity() {
	}

	public EmployeeEntity(String email, String firstName, String lastName,
			String department) {
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;

	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Set<SkillEntity> getSkills() {
		return skills;
	}

	public void setSkills(Set<SkillEntity> skills) {
		this.skills = skills;
	}

	/* Method to CREATE an employee in the database */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#addEmployee(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#addEmployee(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */

	@Override
	public Integer addEmployee(String email, String firstName, String lastName,
			String department) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		Integer employeeID = null;

		try {
			tx = session.beginTransaction();
			EmployeeServices employee = new EmployeeEntity(email, firstName,
					lastName, department);
			employeeID = (Integer) session.save(employee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return employeeID;
	}

	/* Method to READ all the employees */
	/*
	 * // * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#listEmployees()
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#listEmployees()
	 */

	@Override
	public void listEmployees() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			List employees = session.createQuery("FROM EmployeeEntity").list();
			System.out.println("List of all the Employees  are:");
			for (Iterator iterator = employees.iterator(); iterator.hasNext();) {
				EmployeeEntity employee = (EmployeeEntity) iterator.next();
				System.out.print(" Id: " + employee.getEmployeeId());
				System.out.print(" Email: " + employee.getEmail());
				System.out.print(" First Name: " + employee.getFirstName());
				System.out.print(" Last Name: " + employee.getLastName());
				System.out.println(" Department: " + employee.getDepartment());
				System.out.println("Skill: " + employee.getSkills());
			}
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	// Method to READ the employee by id
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#fetchEmployeeById(int)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#fetchEmployeeById(int)
	 */

	@Override
	public void fetchEmployeeById(int id) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			EmployeeEntity employee = (EmployeeEntity) session.get(
					EmployeeEntity.class, id);
			System.out.println("Detail of Employee whose Id is: " + id);
			System.out.print(" Id: " + employee.getEmployeeId());
			System.out.print(" Email: " + employee.getEmail());
			System.out.print(" First Name: " + employee.getFirstName());
			System.out.print(" Last Name: " + employee.getLastName());
			System.out.println(" Department: " + employee.getDepartment());

			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	// Method to READ the employee by department
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ust.model.EmployeeServices#fetchEmployeeByDepartment(java.lang.String
	 * )
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ust.model.EmployeeServices#fetchEmployeeByDepartment(java.lang.String
	 * )
	 */

	@Override
	public void fetchEmployeeByDepartment(String department) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			System.out.println("Detail of Employee whose Department is: "
					+ department);

			Query query = session
					.createQuery("from EmployeeEntity where department = :code ");
			query.setParameter("code", department);
			List list = query.list();
			System.out.println(list);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	/* Method to UPDATE department for an employee */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#updateEmployee(int, java.lang.String)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#updateEmployee(int, java.lang.String)
	 */

	@Override
	public void updateEmployee(int id, String department) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			EmployeeEntity employee = (EmployeeEntity) session.get(
					EmployeeEntity.class, id);
			System.out.println("Updated Employee whose Id is: " + id);
			employee.setDepartment(department);
			session.update(employee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	/* Method to DELETE an employee from the records */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#deleteEmployee(java.lang.Integer)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#deleteEmployee(java.lang.Integer)
	 */

	@Override
	public void deleteEmployee(Integer EmployeeID) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			EmployeeEntity employee = (EmployeeEntity) session.get(
					EmployeeEntity.class, EmployeeID);
			System.out.println("Deleted Employee whose Id is: "
					+ employee.getEmployeeId());
			session.delete(employee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#deleteEmployee(java.lang.Integer)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#countEmployee()
	 */

	@Override
	/* Method to print total number of records */
	public void countEmployee() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			Criteria cr = session.createCriteria(EmployeeEntity.class);

			// To get total row count.
			cr.setProjection(Projections.rowCount());
			List rowCount = cr.list();

			System.out.println("Total Count: " + rowCount.get(0));
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	@Override
	public String toString() {
		return "EmployeeEntity [employeeId=" + employeeId + ", email=" + email
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", department=" + department + " ]";
	}

}
