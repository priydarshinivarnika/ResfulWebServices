package com.ust.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ust.model.EmployeeEntity;
import com.ust.repository.EmployeeRepository;
import com.ust.repository.EmployeeRepositoryImpl;

@Controller
@RequestMapping("/details")
public class EmployeeController {

	// Map to store details of employees
	Map<Integer, EmployeeEntity> empEntity = new HashMap<Integer, EmployeeEntity>();

	private EmployeeRepository empRepo = new EmployeeRepositoryImpl();

	// done
	/*----------url call to to load dummy employees list------------*/
	@RequestMapping(value = EmpUriConstants.DUMMY_EMP, method = RequestMethod.GET)
	public @ResponseBody List<EmployeeEntity> getDummyEmployee() {
		return empRepo.populateDummyEmployees();

	}

	// done
	/*----------url call to get all employees list------------*/
	@RequestMapping(value = EmpUriConstants.GET_ALL_EMP, method = RequestMethod.GET)
	public @ResponseBody List<EmployeeEntity> getAllEmployees() {
		return empRepo.findAllEmployees();
	}

	// done
	/*----------url call to get a specific employee from list by Id------------*/
	@RequestMapping(value = EmpUriConstants.GET_EMP_ID, method = RequestMethod.GET)
	public @ResponseBody EmployeeEntity getEmployeeById(@PathVariable("employeeId") Integer employeeID) {
		System.out.println("Fetching Employee with employeeId =" + employeeID);
		return empRepo.findById(employeeID);

	}

	// done
	/*----------url call to get a specific employee from list by FirstName------------*/
	@RequestMapping(value = EmpUriConstants.GET_EMP_FNAME, method = RequestMethod.GET)
	public @ResponseBody EmployeeEntity getEmployeeByName(@PathVariable("firstName") String firstName) {
		System.out.println("Fetching Employee with FirstName = " + firstName);
		return empRepo.findByFirstName(firstName);

	}

	// done
	/*----------url call to create a new  employee ------------*/
	@RequestMapping(value = EmpUriConstants.CREATE_EMP, method = RequestMethod.POST)
	public @ResponseBody List<EmployeeEntity> createEmployee(@RequestBody EmployeeEntity emp) {
		System.out.println("Details of new employee created");

		return empRepo.createNewEmployee(emp);

	}

	// done
	@RequestMapping(value = EmpUriConstants.DELETE_EMP, method = RequestMethod.PUT)
	public @ResponseBody void deleteEmployee(@PathVariable("employeeId") Integer employeeID) {

		empRepo.deleteEmployeeById(employeeID);
	}

	// done
	@RequestMapping(value = EmpUriConstants.DELETE_ALL_EMP, method = RequestMethod.PUT)
	public @ResponseBody void deleteAll() {

		empRepo.deleteAllEmployees();
	}
	
	// note done
	@RequestMapping(value = EmpUriConstants.UPDATE_EMP, method = RequestMethod.PUT)
	public @ResponseBody EmployeeEntity updateEmployee(@PathVariable("employeeId") Integer employeeID) {

		return empRepo.modifyEmployee(employeeID);

	}
}
