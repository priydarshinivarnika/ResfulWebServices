package com.ust.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ust.model.EmployeeEntity;
import com.ust.repository.EmployeeRepository;
import com.ust.repository.EmployeeRepositoryImpl;

@Controller
@RequestMapping("/details")
public class EmployeeController {

	// Map to store details of employees
	Map<Integer, EmployeeEntity> empData = new HashMap<Integer, EmployeeEntity>();

	private EmployeeRepository empRepo = new EmployeeRepositoryImpl();

	// done
	@RequestMapping(value = EmpUriConstants.DUMMY_EMP, method = RequestMethod.GET)
	public @ResponseBody EmployeeRepositoryImpl getDummyEmployee() {

		EmployeeRepositoryImpl empImpl = new EmployeeRepositoryImpl();
		// EmployeeResourceImpl.populateDummyEmployees();
		return empImpl;

		

	}

	// done
	@RequestMapping(value = EmpUriConstants.CREATE_EMP, method = RequestMethod.POST)
	public @ResponseBody EmployeeEntity createEmployee(@RequestBody EmployeeEntity emp) {
		/*
		 * EmployeeServiceImpl.populateDummyEmployees(); return "ok";
		 */
		empData.put(emp.getEmployeeId(), emp);
		return emp;

	}

	@RequestMapping(value = EmpUriConstants.GET_EMP, method = RequestMethod.GET)
	public @ResponseBody EmployeeEntity getEmployee(@PathVariable("id") int empId) {
		System.out.println("Fetching E with id " + empId);
		return empData.get(empId);

	}

	//------------------working-------
	@RequestMapping(value = EmpUriConstants.GET_ALL_EMP, method = RequestMethod.GET)
	public @ResponseBody List<EmployeeEntity> getAllEmployees() {
		return empRepo.findAllEmployees();
	}

	@RequestMapping(value = EmpUriConstants.UPDATE_EMP, method = RequestMethod.PUT)
	public @ResponseBody EmployeeEntity updateEmployee(@PathVariable("id") int empId) {

		EmployeeEntity emps = empData.get(empId);
		empData.put(emps.getEmployeeId(), emps);
		return emps;

	}

	// done
	@RequestMapping(value = EmpUriConstants.DELETE_EMP, method = RequestMethod.PUT)
	public @ResponseBody EmployeeEntity deleteEmployee(@PathVariable("id") int empId) {

		EmployeeEntity emp = empData.get(empId);
		return empData.remove(emp);
	}

}
