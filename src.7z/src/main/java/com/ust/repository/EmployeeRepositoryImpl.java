package com.ust.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Service;

import com.ust.model.EmployeeEntity;
import com.ust.model.SkillEntity;
import com.ust.utility.HibernateUtil;

public class EmployeeRepositoryImpl implements EmployeeRepository {

	private static List<EmployeeEntity> emps = new ArrayList<EmployeeEntity>(10);

	static {

		System.out.println("Hibernate Many to Many (Annotation mapping)");

		// emps = populateDummyEmployees();
	}

	/*
	 * public static List<EmployeeEntity> populateDummyEmployees() { Session session
	 * = HibernateUtil.getSessionFactory().openSession();
	 * session.beginTransaction(); for (int i = 1; i <= 10; i++) { EmployeeEntity
	 * emp = new EmployeeEntity(); emp.setEmail("xyz@ust.com");
	 * emp.setFirstName("First"); emp.setLastName("Name");
	 * emp.setDepartment("Development"); session.persist(emp); }
	 * session.getTransaction().commit();
	 * System.out.println("successfully saved all the table");
	 * 
	 * session.close(); HibernateUtil.getSessionFactory().close(); return emps; }
	 */

	public List<EmployeeEntity> findAllEmployees() {
		for (int i = 1; i <= 5; i++) {
			EmployeeEntity emp = new EmployeeEntity();
			emp.setEmployeeId(i);
			emp.setEmail("xyz@ust.com");
			emp.setFirstName("First");
			emp.setLastName("Name");
			emp.setDepartment("Development");
			emps.add(emp);
			
			SkillEntity skills = new SkillEntity();
			skills.setSkillId(1);
			skills.setName("Java");
			emp.setSkills(skills);
		}
		return emps;
	}

	public EmployeeEntity findById(Integer employeeID) {

		for (EmployeeEntity emp : emps) {
			if (emp.getEmployeeId() == employeeID) {
				return emp;
			}
		}
		
		
		SkillEntity skills = new SkillEntity();
		skills.setSkillId(1);
		skills.setName("Java");
		
		return null;

	}

	public EmployeeEntity findByFirstName(String firstName) {

		for (EmployeeEntity emp : emps) {
			if (emp.getFirstName() == firstName) {
				return emp;
			}
		}
		return null;
	}

	public void deleteEmployeeById(Integer employeeID) {
		// TODO Auto-generated method stub

	}

	public void deleteAllEmployees() {
		// TODO Auto-generated method stub

	}

	public boolean isEmployeeExist(EmployeeEntity emp) {
		// TODO Auto-generated method stub
		return false;
	}

}
