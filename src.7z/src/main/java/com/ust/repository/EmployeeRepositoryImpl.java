package com.ust.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Service;

import com.ust.model.EmployeeEntity;
import com.ust.model.SkillEntity;
import com.ust.utility.HibernateUtil;

public class EmployeeRepositoryImpl implements EmployeeRepository {

	private static List<EmployeeEntity> emps = new ArrayList<EmployeeEntity>(10);

	static {

		System.out.println("Hibernate Many to Many (Annotation mapping)");
		// emps = populateDummyEmployees();
	}

	/*
	 * public static List<EmployeeEntity> populateDummyEmployees() { Session session
	 * = HibernateUtil.getSessionFactory().openSession();
	 * session.beginTransaction(); for (int i = 1; i <= 10; i++) { EmployeeEntity
	 * emp = new EmployeeEntity(); emp.setEmail("xyz@ust.com");
	 * emp.setFirstName("First"); emp.setLastName("Name");
	 * emp.setDepartment("Development"); session.persist(emp); }
	 * session.getTransaction().commit();
	 * System.out.println("successfully saved all the table");
	 * 
	 * session.close(); HibernateUtil.getSessionFactory().close(); return emps; }
	 */

	public List<EmployeeEntity> findAllEmployees() {
		for (int i = 1; i <= 5; i++) {
			EmployeeEntity emp = new EmployeeEntity();
			emp.setEmployeeId(001);
			emp.setEmail("xyz@ust.com");
			emp.setFirstName("First");
			emp.setLastName("Name");
			emp.setDepartment("Development");
			emps.add(emp);
		}
		return emps;
	}

	public EmployeeEntity findById(long id) {
		for (EmployeeEntity emp : emps) {
			if (emp.getEmployeeId() == id) {
				return emp;
			}
		}
		return null;
	}

	@Override
	public EmployeeEntity findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEmployee(EmployeeEntity emp) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateEmployee(EmployeeEntity emp) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEmployeeById(long id) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAllEmployees() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isEmployeeExist(EmployeeEntity emp) {
		// TODO Auto-generated method stub
		return false;
	}
}
