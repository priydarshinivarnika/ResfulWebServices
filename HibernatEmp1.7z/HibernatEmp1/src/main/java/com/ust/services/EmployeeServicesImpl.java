package com.ust.services;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;

import com.ust.model.EmployeeEntity;
import com.ust.utility.HibernateUtil;

public class EmployeeServicesImpl implements EmployeeServices {

	/* Method to CREATE an employee in the database */
	public Integer addEmployee(String email, String firstName, String lastName, String department) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		Integer employeeID = null;

		try {
			tx = session.beginTransaction();
			EmployeeEntity employee = new EmployeeEntity(email, firstName, lastName, department);
			employeeID = (Integer) session.save(employee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return employeeID;
	}

	/* Method to READ all the employees */
	public void listEmployees() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			List employees = session.createQuery("FROM EmployeeEntity").list();
			System.out.println("List of all the Employees  are:");
			for (Iterator iterator = employees.iterator(); iterator.hasNext();) {
				EmployeeEntity employee = (EmployeeEntity) iterator.next();
				System.out.print(" Id: " + employee.getEmployeeId());
				System.out.print(" Email: " + employee.getEmail());
				System.out.print(" First Name: " + employee.getFirstName());
				System.out.print(" Last Name: " + employee.getLastName());
				System.out.println(" Department: " + employee.getDepartment());
				System.out.println("Skill: " + employee.getSkill());
			}
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	// Method to READ the employee by id
	public void fetchEmployeeById(Integer employeeID) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			EmployeeEntity employee = (EmployeeEntity) session.get(EmployeeEntity.class, employeeID);
			System.out.println("Detail of Employee whose Id is: " + employeeID);
			System.out.print(" Id: " + employee.getEmployeeId());
			System.out.print(" Email: " + employee.getEmail());
			System.out.print(" First Name: " + employee.getFirstName());
			System.out.print(" Last Name: " + employee.getLastName());
			System.out.println(" Department: " + employee.getDepartment());

			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	// Method to READ the employee by department
	public void fetchEmployeeByDepartment(String department) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			System.out.println("Detail of Employee whose Department is: " + department);

			Query query = session.createQuery("from EmployeeEntity where department = :code ");
			query.setParameter("code", department);
			List list = query.list();
			System.out.println(list);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	/* Method to UPDATE department for an employee */
	public void updateEmployee(Integer employeeID, String department) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			EmployeeEntity employee = (EmployeeEntity) session.get(EmployeeEntity.class, employeeID);
			System.out.println("Updated Employee whose Id is: " + employeeID);
			employee.setDepartment(department);
			session.update(employee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	/* Method to DELETE an employee from the records */
	public void deleteEmployee(Integer employeeID) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			EmployeeEntity employee = (EmployeeEntity) session.get(EmployeeEntity.class, employeeID);
			System.out.println("Deleted Employee whose Id is: " + employee.getEmployeeId());
			session.delete(employee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	/* Method to print total number of records */
	public void countEmployee() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			Criteria cr = session.createCriteria(EmployeeEntity.class);

			// To get total row count.
			cr.setProjection(Projections.rowCount());
			List rowCount = cr.list();

			System.out.println("Total Count: " + rowCount.get(0));
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

}
