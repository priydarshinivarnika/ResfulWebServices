package com.ust.model;

public interface SkillServices {

}