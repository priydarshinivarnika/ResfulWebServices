import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.web.client.RestTemplate;

import com.ust.controller.EmpUriConstants;
import com.ust.model.EmployeeEntity;

public class TestSpringRestExample {

	public static final String SERVER_URI = "http://localhost:9090/SpringRestExample";

	public static void main(String args[]) {

		testDummyEmployee();
		System.out.println("*****");
		testCreateEmployee();
		System.out.println("*****");
		testGetEmployee();
		System.out.println("*****");
		testGetAllEmployee();
	}

	private static void testGetAllEmployee() {
		RestTemplate restTemplate = new RestTemplate();
		// we can't get List<Employee> because JSON convertor doesn't know the type of
		// object in the list and hence convert it to default JSON object type
		// LinkedHashMap
		List<LinkedHashMap> emps = restTemplate.getForObject(SERVER_URI + EmpUriConstants.GET_ALL_EMP, List.class);
		System.out.println(emps.size());
		for (LinkedHashMap map : emps) {
			System.out.println("ID=" + map.get("id") + ",FirstName=" + map.get("firstName") + ",Email="
					+ map.get("email") + ",LastName=" + map.get("lastName"));

		}
	}

	private static void testCreateEmployee() {
		RestTemplate restTemplate = new RestTemplate();
		EmployeeEntity emp = new EmployeeEntity();	
		emp.setEmployeeId(1);
		emp.setEmail("123@email.com");
		emp.setFirstName("Paresh");
		emp.setLastName("Rawal");
		emp.setDepartment("Physics");
		EmployeeEntity response = restTemplate.postForObject(SERVER_URI + EmpUriConstants.CREATE_EMP, emp,
				EmployeeEntity.class);
		printEmpData(response);
	}

	private static void testGetEmployee() {
		RestTemplate restTemplate = new RestTemplate();
		EmployeeEntity emp = restTemplate.getForObject(SERVER_URI + "/rest/emp/1", EmployeeEntity.class);
		printEmpData(emp);
	}

	private static void testDummyEmployee() {
		RestTemplate restTemplate = new RestTemplate();
		EmployeeEntity emp = restTemplate.getForObject(SERVER_URI + EmpUriConstants.DUMMY_EMP, EmployeeEntity.class);
		printEmpData(emp);
	}

	public static void printEmpData(EmployeeEntity emp) {
		System.out.println(
				"ID=" + emp.getEmployeeId() + ",FirstName=" + emp.getFirstName() + ",Email="
						+ emp.getEmail() + ",LastName=" + emp.getLastName() + "Department=" + emp.getDepartment());
	}
}
