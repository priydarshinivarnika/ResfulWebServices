package com.business.world.util;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

import com.business.world.entity.AddressEntity;
import com.business.world.entity.EmployeeEntity;

public class TestExcelWriter {

	private static final String FILE_PATH = "/Users/vxp142/CUP/BusinessWorld/EmployeeList.xlsx";
	
	@Test
	public void testingExcelWriter(){
	
	
		//Create a blank WORKBOOK
        Workbook workbook = new XSSFWorkbook();
         
        //Create a blank SHEET
        XSSFSheet sheet = (XSSFSheet) workbook.createSheet("Employee Data");
          
        //This data needs to be written (Object[])
        Map<String, Object[]> data = new TreeMap<String, Object[]>();
        data.put("1", new Object[] {"EMPLOYEE_ID","ID", "FIRSTNAME", "LASTNAME", "SALARY", "CITY", "STATE"});
        data.put("2", new Object[] {1, "U60100", "Amit", "Shukla", 1234, "ABC1", "XYZ1"});
        data.put("3", new Object[] {2, "U60101", "Lokesh", "Gupta", 1234, "ABC2", "XYZ2"});
        data.put("4", new Object[] {3, "U60102", "John", "Adwards", 1234, "ABC3", "XYZ3"});
        data.put("5", new Object[] {4, "U60103", "Brian", "Schultz", 1234, "ABC4", "XYZ4"});
         
        
        
       
	
    	/*public void testExcelWriter() {

    		List<EmployeeEntity> empList = new ArrayList<>();
    		List<AddressEntity> addEntity  = new ArrayList<>();
    		
    		//create a work book
            Workbook workbook = new XSSFWorkbook();
    		
    		// Create a blank sheet
    		XSSFSheet sheet = (XSSFSheet) workbook.createSheet("Employee Data");

    		// This data needs to be written (Object[])
    		Map<String, Object[]> data = new TreeMap<String, Object[]>();
    		int counter = 0;
    		data.put("1", new Object[] {"ID", "FIRSTNAME", "LASTNAME", "SALARY", "CITY_NAME", "TELEPHONE_NUMBER", "ZIP_CODE", "HOUSE_NUMBER", "STREET_NAME", "ADDRESS_TYPE", "STREET_TYPE" });
            for(EmployeeEntity ee : empList) {
                data.put(new Integer(counter++).toString(), new Object[] {ee.getId(), ee.getFirstname(), ee.getLastname(), ee.getSalary()});
                for(AddressEntity ae: addEntity){
                	data.put(null, new Object[] {ae.getZipCode(), ae.getHouseNumber(),ae.getStreetName(), ae.getAddressType(), ae.getStreetType()});
                }
            }
        */
        
        
        
        
        
        //Iterate over data and write to sheet
        Set<String> keyset = data.keySet(); 
        int rownum = 0;
        for (String key : keyset)
        {
            Row row = sheet.createRow(rownum++);
            Object [] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr)
            {
               Cell cell = row.createCell(cellnum++);
               if(obj instanceof String)
                    cell.setCellValue((String)obj);
                else if(obj instanceof Integer)
                    cell.setCellValue((Integer)obj);
            }
        }
        try
        {
            //Write the workbook in file system
            FileOutputStream out = new FileOutputStream(new File(FILE_PATH));
            workbook.write(out);
            out.close();
            System.out.println("EmployeeList.xlsx written successfully on disk within the project.");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
