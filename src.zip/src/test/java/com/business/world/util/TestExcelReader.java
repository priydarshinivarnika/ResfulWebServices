package com.business.world.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

public class TestExcelReader {

	private static final String FILE_PATH = "/Users/vxp142/CUP/BusinessWorld/EmployeeList.xlsx";
	ArrayList myList = new ArrayList();

	@Test
	public void getEmployeesListFromExcel() {

		FileInputStream fis = null;
		try {
			fis = new FileInputStream(new File(FILE_PATH));

			Workbook workbook = new XSSFWorkbook(fis);
			int numberOfSheets = workbook.getNumberOfSheets();

			for (int i = 0; i < numberOfSheets; i++) {
				Sheet sheet = workbook.getSheetAt(0);
				Iterator<Row> rowIterator = sheet.iterator();

				while (rowIterator.hasNext()) {

					Row row = rowIterator.next();
					Iterator<Cell> cellIterator = row.cellIterator();

					while (cellIterator.hasNext()) {
						Cell cell = cellIterator.next();
						switch (cell.getCellType()) {
						case NUMERIC:
							System.out.print(cell.getNumericCellValue() + "\t");
							myList.add(cell.getNumericCellValue());
							break;
						case STRING:
							System.out.print(cell.getStringCellValue() + "\t");
							myList.add(cell.getRichStringCellValue());
							break;
						case BOOLEAN:
							System.out.print(cell.getBooleanCellValue() + "\t");
							myList.add(cell.getBooleanCellValue());
							break;
						}

					}
					System.out.println("");
				}
			}
			fis.close();
			workbook.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
