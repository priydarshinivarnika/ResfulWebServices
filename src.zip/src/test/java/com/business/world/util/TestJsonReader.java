package com.business.world.util;

import com.business.world.entity.AddressEntity;
import com.business.world.entity.EmployeeEntity;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class TestJsonReader {

	@Test
	public void testJsonToEmployee() {
		List<EmployeeEntity> empList = new ArrayList<>();
		AddressEntity add = new AddressEntity();
		add.setCityName("MAYSVILLE");
		add.setTelephoneNumber(9600568708L);
		add.setZipCode(41056);
		add.setHouseNumber(45);
		add.setStreetName("MEADOW");
		add.setAddressType("CA");
		add.setStreetType("DR 45");
		

		EmployeeEntity e = new EmployeeEntity();
		e.setId("U76090");
		e.setFirstname("Jeff");
		e.setLastname("Bezos");
		e.setSalary(56000);
		e.setAddress(add);
		empList.add(e);

		/*AddressEntity add2 = new AddressEntity();
		add2.setCityName("Ahmedabad");
		add2.setTelephoneNumber(1110568708L);
		add2.setZipCode(795543);
		add2.setHouseNumber(12);
		add2.setStreetName("Jhulelal");
		add2.setAddressType("Gujrat");
		add2.setStreetType("12 Cariappa");

		EmployeeEntity e2 = new EmployeeEntity();
		
		e2.setId("emp125");
		e2.setFirstname("Vicky");
		e2.setLastname("Malhotra");
		e2.setSalary(34567);
		e2.setAddress(add2);

		empList.add(e2);*/

		System.out.println(JsonReader.employeeToJson(empList));
		// System.out.println(JsonReader.employeeToJson(e2));
		// System.out.print(str);
	}
}
