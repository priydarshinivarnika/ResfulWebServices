CREATE SEQUENCE address_id_seq;

CREATE SEQUENCE employee_id_seq;

CREATE TABLE ADDRESS (
 ADDRESS_ID integer DEFAULT nextval('address_id_seq') primary key,
 CITY_NAME varchar(11) NOT NULL ,
 TELEPHONE_NUMBER INTEGER DEFAULT NULL,
 ZIP_CODE INTEGER NOT NULL,
 HOUSE_NUMBER INTEGER DEFAULT NULL,
 STREET_NAME varchar(100) DEFAULT NULL,
 ADDRESS_TYPE VARCHAR(100) DEFAULT NULL,
 STREET_TYPE VARCHAR(100) DEFAULT NULL
);

CREATE TABLE EMPLOYEE(
 EMPLOYEE_ID integer DEFAULT nextval('employee_id_seq')  primary key,
 ID varchar(20) unique NOT NULL,
 FIRST_NAME varchar(11) NOT NULL ,
 LAST_NAME varchar(100) NOT NULL,
 SALARY varchar(100) DEFAULT NULL,
 ADDRESS_ID integer NOT null,
 constraint employee_address_key foreign key (ADDRESS_ID) references ADDRESS (ADDRESS_ID)
);


