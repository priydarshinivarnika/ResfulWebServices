package com.business.world.dao;

import com.business.world.entity.EmployeeEntity;

public interface IDatabaseAccess {

	public void createEmployee(EmployeeEntity emp);
	public void updateEmployee(EmployeeEntity emp);

	public void delete(String id);

	public void deleteEmployee(String id);

}
