package com.business.world.dao;

import java.util.Iterator;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.business.world.entity.EmployeeEntity;

@Repository
public class DatabaseAccess implements IDatabaseAccess {

	private static final SessionFactory sessionFactory;
	// private static List<EmployeeEntity> empList = new
	// ArrayList<EmployeeEntity>(10);

	static {
		try {
			Configuration config = new Configuration();
			sessionFactory = config.configure().buildSessionFactory();
		} catch (Throwable e) {
			System.err.println("Error in creating SessionFactory object."
					+ e.getMessage());
			throw new ExceptionInInitializerError(e);
		}
	}

	// Method To Find Particular Record In The Database Table
	public static EmployeeEntity findRecordById(String id) {
		EmployeeEntity findEmpObj = null;

		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		transaction = session.beginTransaction();

		findEmpObj = (EmployeeEntity) session.load(EmployeeEntity.class, id);

		transaction.commit();
		return findEmpObj;

	}

	@Override
	public void createEmployee(EmployeeEntity emp) {
		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		transaction = session.beginTransaction();
		session.saveOrUpdate(emp);
		transaction.commit();

	}

	@Override
	public void updateEmployee(EmployeeEntity emp) {
		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		transaction = session.beginTransaction();
		
		//get the id of the record
		//look for the id existence in db using loop
		//if matched update it 
		//if not msg not exist

		/*String empId = emp.getId();
		for (Iterator iterator = emp.iterator(); iterator.hasNext();) {
			EmployeeEntity emp1 = iterator.next();
			if (emp1.getId() == id) {
				iterator.remove();
			}
		}*/
		
		
		session.merge(emp);
		transaction.commit();

	}

	/*
	 * public void deleteEmployee(String id){ Session session =
	 * sessionFactory.openSession(); Transaction transaction = null; transaction
	 * = session.beginTransaction(); for (Iterator<EmployeeEntity> iterator =
	 * empList.iterator(); iterator.hasNext();) { EmployeeEntity emp1 =
	 * iterator.next(); if (emp1.getId() == id) { iterator.remove(); } }
	 * session.delete(empList); transaction.commit();
	 * System.out.println("-----------------into deleteEmployee---------------"
	 * ); }
	 */

	@Override
	public void deleteEmployee(String id) {
		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		transaction = session.beginTransaction();
		EmployeeEntity emp = new EmployeeEntity();
		
		emp.setId(id);
		// session.createSQLQuery(Constant.DELETE_QUERY + st).executeUpdate();

		session.delete(emp.getId());
		transaction.commit();

		System.out
				.println("-----------------into deleteEmployee---------------");
	}

	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub

	}

}
