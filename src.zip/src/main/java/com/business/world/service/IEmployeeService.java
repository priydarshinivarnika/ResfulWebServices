package com.business.world.service;

import com.business.world.entity.EmployeeEntity;

public interface IEmployeeService {	

	public void createEmployee(EmployeeEntity emp);
	public void updateEmployee(EmployeeEntity emp);
}
