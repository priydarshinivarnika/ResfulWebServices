package com.business.world.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.business.world.dao.IDatabaseAccess;
import com.business.world.entity.EmployeeEntity;

@Service
public class EmployeeServiceImpl implements IEmployeeService{

	@Autowired	
	private IDatabaseAccess daoAccess;	
	
	@Override
	public void createEmployee(EmployeeEntity emp) {
	
	
	
		daoAccess.createEmployee(emp);
	System.out.println("Employee " + emp.getId() + " Inserted Successfully");
	}

	@Override
	public void updateEmployee(EmployeeEntity emp) {
		daoAccess.updateEmployee(emp);
		
	}
}
