package com.business.world.domain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.business.world")
public class EmployeeApi {
	public static void main(String[] args) {

		SpringApplication.run(EmployeeApi.class, args);

	}
}
