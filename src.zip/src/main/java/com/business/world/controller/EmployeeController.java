package com.business.world.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.business.world.dao.DatabaseAccess;
import com.business.world.entity.EmployeeEntity;
import com.business.world.service.IEmployeeService;
import com.business.world.util.JsonReader;

@RestController
public class EmployeeController {

	@Autowired
	private IEmployeeService empService;
	
	@RequestMapping("/hello")
	public String hello() {
		return "Welcome to Spring Boot Project";
	}

	@PostMapping(value = "/insertEmployee")
	@ResponseBody
	public String insertRecord(@RequestBody String json) {
		System.out.println("Inside insertRecord");
		EmployeeEntity emp = JsonReader.jsonToEmployee(json);
		System.out.println("Employee created : " + emp.getFirstname());	
		empService.createEmployee(emp);
		return "Employee " + emp.getId() + " Inserted Successfully";
	}	

	@PutMapping(value="/updateEmployee")
	@ResponseBody
	public String updateRecord(@RequestBody String json){
		System.out.println("Inside updateRecord");
		EmployeeEntity emp = JsonReader.jsonToEmployee(json);
		System.out.println("Employee updated : " + emp.getFirstname());
		empService.updateEmployee(emp);
		return "Employee " + emp.getId() + " Updated Successfully";
	}

	@DeleteMapping(value = "/deleteEmployee/{id}")
	@ResponseBody
	public String deleteRecord(@PathVariable("id") String id) {
		System.out.println("Inside delete Record");
		
		new DatabaseAccess().deleteEmployee(id);
				
		
		/*try {
			EmployeeEntity emp = new EmployeeEntity();

			emp.setId(id);
			new DatabaseAccess().delete(emp);
		} catch (Exception ex) {
			return ex.getMessage();
		}*/
		return "Employee succesfully deleted!";
	}

}
