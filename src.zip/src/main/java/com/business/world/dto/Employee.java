package com.business.world.dto;

public class Employee {
	private int employeeId;
	private String id;
	private String firstname;
	private String lastname;
	private int salary;
	private Address address;

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee{" + "id='" + id + '\'' + ", firstname='" + firstname
				+ '\'' + ", lastname='" + lastname + '\'' + ", salary="
				+ salary + ", address=" + address + '}';
	}
}
