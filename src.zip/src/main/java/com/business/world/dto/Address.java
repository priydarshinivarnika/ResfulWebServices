package com.business.world.dto;

public class Address {
    private int addressId;
    private String cityName;
    private long telephoneNumber;
    private int zipCode;
    private int houseNumber;
    private String streetName;
    private String addressType;
    private String streetType;
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public long getTelephoneNumber() {
		return telephoneNumber;
	}
	public void setTelephoneNumber(long telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}
	public int getZipCode() {
		return zipCode;
	}
	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}
	public int getHouseNumber() {
		return houseNumber;
	}
	public void setHouseNumber(int houseNumber) {
		this.houseNumber = houseNumber;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getAddressType() {
		return addressType;
	}
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
	public String getStreetType() {
		return streetType;
	}
	public void setStreetType(String streetType) {
		this.streetType = streetType;
	}
	@Override
	public String toString() {
		return "Address {cityName=" + cityName
				+ ", telephoneNumber=" + telephoneNumber + ", zipCode="
				+ zipCode + ", houseNumber=" + houseNumber + ", streetName="
				+ streetName + ", addressType=" + addressType + ", streetType="
				+ streetType + "}";
	}
    
    

    
}
