package com.business.world.util;

public class Constant {

	public static final String DELETE_QUERY = "delete * FROM EMPLOYEE WHERE ID =";
	
}
