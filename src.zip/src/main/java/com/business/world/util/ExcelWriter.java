package com.business.world.util;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.business.world.entity.AddressEntity;
import com.business.world.entity.EmployeeEntity;

public class ExcelWriter {

	private static final String FILE_PATH = "/Users/vxp142/CUP/BusinessWorld/EmployeeList.xlsx";

	public void testExcelWriter(List<EmployeeEntity> emp, List<AddressEntity> add) {

		List<EmployeeEntity> empList = new ArrayList<>();
		List<AddressEntity> addEntity  = new ArrayList<>();
		
		//create a work book
        Workbook workbook = new XSSFWorkbook();
		
		// Create a blank sheet
		XSSFSheet sheet = (XSSFSheet) workbook.createSheet("Employee Data");

		// This data needs to be written (Object[])
		Map<String, Object[]> data = new TreeMap<String, Object[]>();
		int counter = 0;
		data.put("1", new Object[] {"ID", "FIRSTNAME", "LASTNAME", "SALARY", "CITY_NAME", "TELEPHONE_NUMBER", "ZIP_CODE", "HOUSE_NUMBER", "STREET_NAME", "ADDRESS_TYPE", "STREET_TYPE" });
        for(EmployeeEntity ee : empList) {
            data.put(new Integer(counter++).toString(), new Object[] {ee.getId(), ee.getFirstname(), ee.getLastname(), ee.getSalary()});
            for(AddressEntity ae: addEntity){
            	data.put(null, new Object[] {ae.getZipCode(), ae.getHouseNumber(),ae.getStreetName(), ae.getAddressType(), ae.getStreetType()});
            }
        }
		// Iterate over data and write to sheet
		Set<String> keyset = data.keySet();
		int rownum = 0;
		for (String key : keyset) {
			Row row = sheet.createRow(rownum++);
			Object[] objArr = data.get(key);
			int cellnum = 0;
			for (Object obj : objArr) {
				Cell cell = row.createCell(cellnum++);
				if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Integer)
					cell.setCellValue((Integer) obj);
			}
		}
		try {
			// Write the workbook in file system
			FileOutputStream out = new FileOutputStream(new File(FILE_PATH));
			workbook.write(out);
			out.close();
			System.out
					.println("EmployeeList.xlsx written successfully on disk within the project.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
