package com.ust.services;

public interface SkillServices {

}