package com.common.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.common.model.Employee;
import com.common.service.EmployeeService;

@RestController
public class EmployeeController {

  @Autowired
   private EmployeeService employeeService;

   /*---Add new Employee---*/
   @PostMapping("/employee")
   public ResponseEntity<?> save(@RequestBody Employee emp) {
      long id = employeeService.save(emp);
      
      return ResponseEntity.ok().body("New Employee has been saved with ID:" + id);
   }

   /*---Get an Employee by id---*/
   @GetMapping("/employee/{id}")
   public ResponseEntity<Employee> get(@PathVariable("id") long id) {
      Employee emp = employeeService.get(id);
      return ResponseEntity.ok().body(emp);
   }

   /*---get all Employees---*/
   @GetMapping("/employee")
   public ResponseEntity<List<Employee>> list() {
      List<Employee> emps = employeeService.list();
      return ResponseEntity.ok().body(emps);
   }

   /*---Update an Employee by id---*/
   @PutMapping("/employee/{id}")
   public ResponseEntity<?> update(@PathVariable("id") long id, @RequestBody Employee emp) {
	   employeeService.update(id, emp);
      return ResponseEntity.ok().body("Employee has been updated successfully.");
   }

   /*---Delete an employee by id---*/
   @DeleteMapping("/employee/{id}")
   public ResponseEntity<?> delete(@PathVariable("id") long id) {
	   employeeService.delete(id);
      return ResponseEntity.ok().body("Employee has been deleted successfully.");
   }
}