package com.ust.repository;

import java.util.List;

import com.ust.model.EmployeeEntity;
import com.ust.model.SkillEntity;

public interface EmployeeRepository {

	List<EmployeeEntity> populateDummyEmployees();
	
	List<EmployeeEntity> findAllEmployees();

	EmployeeEntity findById(Integer employeeID);

	
	
	

	EmployeeEntity findByFirstName(String firstName);

	void deleteEmployeeById(Integer employeeID);

	void deleteAllEmployees();

	public boolean isEmployeeExist(EmployeeEntity emp);

	

}
