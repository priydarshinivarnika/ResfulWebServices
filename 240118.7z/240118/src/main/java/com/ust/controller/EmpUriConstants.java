package com.ust.controller;

public class EmpUriConstants {

	public static final String GET_ALL_EMP = "/emps";
	public static final String GET_EMP_ID= "/emp/id/{employeeId}";
	public static final String GET_EMP_ID_SKILL = "/emp/id/{employeeId}/{skill}";
	
	public static final String GET_EMP_FNAME = "/emp/name/{firstName}";
	public static final String DUMMY_EMP = "/emp/dummy";
	public static final String CREATE_EMP = "/emp/create";
	public static final String UPDATE_EMP = "/emp/update/{id}";
	public static final String DELETE_EMP = "/emp/delete/{employeeId}";

}
