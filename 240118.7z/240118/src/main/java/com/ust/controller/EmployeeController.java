package com.ust.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ust.model.EmployeeEntity;
import com.ust.model.SkillEntity;
import com.ust.repository.EmployeeRepository;
import com.ust.repository.EmployeeRepositoryImpl;

@Controller
@RequestMapping("/details")
public class EmployeeController {

	// Map to store details of employees
	Map<Integer, EmployeeEntity> empEntity = new HashMap<Integer, EmployeeEntity>();

	private EmployeeRepository empRepo = new EmployeeRepositoryImpl();

	// ------------------working-------

	/*----------url call to get all employees list------------*/
	@RequestMapping(value = EmpUriConstants.GET_ALL_EMP, method = RequestMethod.GET)
	public @ResponseBody List<EmployeeEntity> getAllEmployees() {
		return empRepo.findAllEmployees();
	}

	/*----------url call to get a specific employee from list by Id------------*/
	@RequestMapping(value = EmpUriConstants.GET_EMP_ID, method = RequestMethod.GET)
	public @ResponseBody EmployeeEntity getEmployeeById(@PathVariable("employeeId") Integer employeeID) {
		System.out.println("Fetching Employee with employeeId =" + employeeID);
		return empRepo.findById(employeeID);

	}

	@RequestMapping(value = EmpUriConstants.CREATE_EMP, method = RequestMethod.POST)
	public @ResponseBody EmployeeEntity createEmployee(@RequestBody EmployeeEntity emp) {

		empEntity.put(emp.getEmployeeId(), emp);
		return emp;

	}

	/*----------url call to get a specific employee from list by FirstName------------*/
	@RequestMapping(value = EmpUriConstants.GET_EMP_FNAME, method = RequestMethod.GET)
	public @ResponseBody EmployeeEntity getEmployeeByName(@PathVariable("firstName") String firstName) {
		System.out.println("Fetching Employee with FirstName = " + firstName);
		return empRepo.findByFirstName(firstName);

	}

	// done
	@RequestMapping(value = EmpUriConstants.DUMMY_EMP, method = RequestMethod.GET)
	public @ResponseBody List<EmployeeEntity> getDummyEmployee() {
		return empRepo.populateDummyEmployees();

	}

	// done

	@RequestMapping(value = EmpUriConstants.UPDATE_EMP, method = RequestMethod.PUT)
	public @ResponseBody EmployeeEntity updateEmployee(@PathVariable("employeeId") Integer employeeID) {

		EmployeeEntity emps = empEntity.get(employeeID);
		empEntity.put(emps.getEmployeeId(), emps);
		return emps;

	}

	// done
	@RequestMapping(value = EmpUriConstants.DELETE_EMP, method = RequestMethod.PUT)
	public @ResponseBody EmployeeEntity deleteEmployee(@PathVariable("employeeId") Integer employeeID) {

		EmployeeEntity emp = empRepo.findById(employeeID);
		return empEntity.remove(emp);
	}

}
